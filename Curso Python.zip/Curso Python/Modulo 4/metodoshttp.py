import requests
host = "http://testphp.vulnweb.com/"
metodos = ['OPTIONS', 'GET', 'POST', 'DELETE', 'TRACE', 'CONNECT']
for metodo in metodos:
    resposta = requests.request(metodo, host)
    print(metodo, "->", resposta.reason)
