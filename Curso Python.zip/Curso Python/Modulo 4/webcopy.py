from pywebcopy import save_webpage
 
kwargs = {'project_name': 'site folder'}
 
save_webpage(
   
    # url of the website
    url='http://pudim.com.br/',
     
    # folder where the copy will be saved
    project_folder='pycopy/',
    **kwargs
)
