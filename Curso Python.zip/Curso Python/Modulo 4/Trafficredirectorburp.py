# -*- coding: utf-8 -*-

#Bibliotecas 
from burp import IBurpExtender
from burp import IHttpListener
from java.io import PrintWriter

HOST_FROM = "127.0.0.1"
HOST_TO = "www.google.com"

class BurpExtender(IBurpExtender, IHttpListener):

    #
    # implement IBurpExtender
    #
    
    def	registerExtenderCallbacks(self, callbacks):
        # obtain an extension helpers object
        self._helpers = callbacks.getHelpers()
        
        # set our extension name
        callbacks.setExtensionName("Traffic redirector")

        self.stdout = PrintWriter(callbacks.getStdout(), True);
        self.stdout.println("DEBUG: Habilitado!")
        
        # register ourselves as an HTTP listener
        callbacks.registerHttpListener(self)

    #
    # implement IHttpListener
    #
    
    def processHttpMessage(self, toolFlag, messageIsRequest, messageInfo):
        
        self.stdout.println("DEBUG: Entrando na funcao processHttpMessage") 
        # only process requests
        if not messageIsRequest:
            self.stdout.println("Debug: Essa mensagem não é uma requisicao, parando processo")
            return

        # get the HTTP service for the request
        httpService = messageInfo.getHttpService()
        self.stdout.print("Debug: httpservice ")
        self.stdout.println(httpService)
        self.stdout.print("Debug: httpservice.gethost() ")
        self.stdout.println(httpService.getHost())
        self.stdout.print("Debug: HOST_TO")
        self.stdout.println(HOST_TO)
        self.stdout.print("Debug: HOST_FROM ")
        self.stdout.println(HOST_FROM)
        
        # if the host is HOST_FROM, change it to HOST_TO
        if (HOST_FROM == httpService.getHost()):
            self.stdout.println("Debug: HOST_TO and HOST_FROM are the same server")
            messageInfo.setHttpService(self._helpers.buildHttpService(HOST_TO,
                httpService.getPort(), httpService.getProtocol()))
            self.stdout.println("Debug: Se o for HOST_FROM, mude para o HOST_TO ")
            self.stdout.println(httpService)
