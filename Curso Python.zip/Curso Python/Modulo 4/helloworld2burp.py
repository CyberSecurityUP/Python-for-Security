from burp import IBurpExtender


class BurpExtender(IBurpExtender):
    
    def registerExtenderCallbacks(self,callbacks):
        callbacks.setExtensionName("Hello World2")
        for x in xrange(1,100):
            string = "hello " + str(x)
            callbacks.printOutput(string)
        return
