#Variaveis
nome = 'Joas'
idade = 27
altura = 1.73
calc1 = 4-3j
verdade = False

#TIPOS
tipo_nome = type(nome)
tipo_idade = type(idade)
tipo_altura = type(altura)
tipo_calc1 = type(calc1)
tipo_verdade = type(verdade)

#PRINTANDO OS TIPOS DE VARIAVEIS
print(tipo_nome)
print(tipo_idade)
print(tipo_altura)
print(tipo_calc1)
print(tipo_verdade)
