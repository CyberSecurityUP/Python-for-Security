
#with open('readme.txt', 'w') as f:
 #   f.write('readme')



#lines = ['Readme', 'How to write text files in Python']
#with open('readme.txt', 'w') as f:
 #   for line in lines:
  #      f.write(line)
   #     f.write('\n')


#more_lines = ['', 'Append text files', 'The End']

#with open('readme.txt', 'a') as f:
 #   f.write('\n'.join(more_lines))


#f = open("readme.txt", "r")
#print(f.read())


#with open('readme.txt') as f:
 #   lines = f.readlines()
  #  print(lines)
