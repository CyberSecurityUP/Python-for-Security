#print("Hello World")

#hello = 'Hello World'
#print(hello)

#hello3 = input("Digite o Hello World:\n")
#print(hello3)

#Input = Entrada de dados
#output = saida de dados

#Input Example: Teclado e o Mouse
#Output: Monitor


#print("Ola a todos bem vindo ao curso")
#nome = input("Qual é o seu nome: ") #Abri a variavel nome ao qual vai receber uma entrada de dados, que seria no caso algum nome
#print(nome) #Aqui eu imprimo na tela o nome que foi armazenado na variavel "nome" pelo input

#num1 = input("Digite algum numero: ") #Abri a variavel num1 e num2 que está esperando algum valor 
#num2 = input("Digite algum numero: ")

#resultado = (num1 - num2) #Aqui está a variavel resultado fazendo a subtração dos valores correspondente da variavel num1 - num2
#print("O resultado da soma é", resultado) #Aqui é o resultado da soma

#nome = str(input("Digite o seu Nome: ")) #Armazenar variavel do tipo texto "Hello"
#idade = int(input("Digite a sua Idade: ")) #Do tipo número inteiro 10
#altura = float(input("Digite a sua altura: ")) #Do tipo número quebrado "1.80"
#peso = float(input("Digite o seu peso: ")) #Do tipo numero quebrado "1.80"

#print("O SEU NOME É", nome, "SUA IDADE É", idade, "A SUA ALTURA É", altura)
#print(f"O Seu nome é {nome} sua idade é {idade} e sua altura é {altura}")

# Recebe dados do usuário
var1 = float( input("Digite um numero: ") )
var2 = float( input("Digite outro numero: ") )

# Imprime o resultado das operações direto na função print
print('Soma:             ', var1,'+',var2,' = ' , var1+var2)
print('Subtração:        ', var1,'-',var2,' = ' , var1-var2)
print('Multiplicação:    ', var1,'*',var2,' = ' , var1*var2)
print('Divisão:          ', var1,'/',var2,' = ' , var1/var2)
print('Exponenciação:    ', var1,'**',var2,' = ', var1**var2)
print('Resto da divisão: ', var1,'%',var2,' = ' , var1%var2)
