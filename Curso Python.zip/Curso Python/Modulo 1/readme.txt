Readme
How to write text files in Python

Append text files
The End