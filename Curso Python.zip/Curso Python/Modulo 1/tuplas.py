times_rj = ('Botafogo', 'Flamengo', 'Fluminense', 'Vasco')

print(type(times_rj)) # class=’tuple’
print(times_rj) # ('Botafogo', 'Flamengo', 'Fluminense', 'Vasco')

times_rj = ('Botafogo', 'Flamengo', 'Fluminense', 'Vasco')

print(times_rj[2]) # Fluminense

vogais = ('a', 'e', 'i', 'o', 'u')

print(vogais[1]) # e
