#Ele é executado assim que um objeto de uma classe é instanciado. O método é útil para fazer
#qualquer inicialização que você queira fazer com seu objeto.
class Pessoa:
    def __init__(self, nome):
        self.nome = nome
    def __str__(self):
        return self.nome

joas = Pessoa('Joas')
print(joas)
michael = Pessoa('Michael')
print(michael)
lucas = Pessoa('Lucas')
print(lucas)

class Dog:
 
    # A simple class
    # attribute
    attr1 = "spike"
    attr2 = "bob"
 
    # A sample method
    def fun(self):
        print("I'm a", self.attr1)
        print("I'm a", self.attr2)
 
 
#Código do motorista
# Instanciação do objeto
Rodger = Dog()
 
# Acessando atributos de classe
# e método através de objetos
print(Rodger.attr1)
Rodger.fun()
