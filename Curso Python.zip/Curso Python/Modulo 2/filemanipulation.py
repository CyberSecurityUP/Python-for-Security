# Open a file
#fo = open("test.txt", "wb")
#print ("Name of the file: ", fo.name)

# Close opend file
#fo.close()


#create file and write
#file = open('geek.txt','w')
#file.write("This is the write command")
#file.write("It allows us to write in a particular file")
#file.close()


# Open a file
#fo = open("test.txt", "w")
#fo.write("Python is a great language\nYeah its great!!\n")

# Close opend file
#fo.close()

#import os

# Rename a file from test1.txt to test2.txt
#os.rename( "test.txt", "test2.txt" )

import os

# Delete file test2.txt
os.remove("test2.txt")
